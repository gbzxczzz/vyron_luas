-- 2333000's Lua and Manifest Created by Hubcap Manifest
-- Silver Pines
-- Created: October 16, 2026 at 07:49:46 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25964535 (public branch)
-- Build Date: October 15, 2026 at 12:02:11 EDT (1792080131)
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2333000) -- Silver Pines
-- MAIN APP DEPOTS
addappid(2333001, 1, "aed805bf1a8e2e54edd25436fa4d2144e3dd02ce5c0360f2baa9d9b67c7ac95b") -- Depot 2333001
setManifestid(2333001, "8784396639484429591", 3848425448)
-- DLCS WITH DEDICATED DEPOTS
-- Silver Pines - Artbook (AppID: 4677930)
addappid(4677930)
addappid(4677931, 1, "fd8658494b1443332015e1d5f8c48c7c936875ea5e937997a3480c4d92a6a393") -- Silver Pines - Artbook - Depot 4677931
setManifestid(4677931, "769645333623634749", 103204332)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2333002) -- Depot 2333002 (empty depot)